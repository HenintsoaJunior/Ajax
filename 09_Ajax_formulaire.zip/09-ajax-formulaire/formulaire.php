<?php
 session_start();
 $name=$_POST['anarana'];
 $_SESSION['name']= $name;

?>